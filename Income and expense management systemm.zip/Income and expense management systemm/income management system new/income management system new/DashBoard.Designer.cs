﻿namespace income_management_system_new
{
    partial class DashBoard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DashBoard));
            this.panel1 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.IncLbl = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.pictureBox9 = new System.Windows.Forms.PictureBox();
            this.label9 = new System.Windows.Forms.Label();
            this.TotIncLbl = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.NumIncLbl = new System.Windows.Forms.Label();
            this.DateIncLbl = new System.Windows.Forms.Label();
            this.DateExpLbl = new System.Windows.Forms.Label();
            this.NumExpLbl = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.TotExpLbl = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.pictureBox10 = new System.Windows.Forms.PictureBox();
            this.pictureBox11 = new System.Windows.Forms.PictureBox();
            this.pictureBox12 = new System.Windows.Forms.PictureBox();
            this.label23 = new System.Windows.Forms.Label();
            this.pictureBox14 = new System.Windows.Forms.PictureBox();
            this.MaxIncLbl = new System.Windows.Forms.Label();
            this.MaxExpLbl = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.pictureBox13 = new System.Windows.Forms.PictureBox();
            this.MinIncLbl = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.pictureBox15 = new System.Windows.Forms.PictureBox();
            this.MinExpLbl = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.pictureBox16 = new System.Windows.Forms.PictureBox();
            this.BestIncLbl = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.pictureBox17 = new System.Windows.Forms.PictureBox();
            this.BalanceLbl = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.pictureBox18 = new System.Windows.Forms.PictureBox();
            this.DateExpLbl1 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.pictureBox19 = new System.Windows.Forms.PictureBox();
            this.DateIncLbl1 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.pictureBox20 = new System.Windows.Forms.PictureBox();
            this.BestExpLbl = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.pictureBox21 = new System.Windows.Forms.PictureBox();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.LavenderBlush;
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.IncLbl);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.pictureBox7);
            this.panel1.Controls.Add(this.pictureBox6);
            this.panel1.Controls.Add(this.pictureBox5);
            this.panel1.Controls.Add(this.pictureBox4);
            this.panel1.Controls.Add(this.pictureBox3);
            this.panel1.Controls.Add(this.pictureBox2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(324, 913);
            this.panel1.TabIndex = 0;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(33, 28);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(75, 73);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Modern No. 20", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(114, 48);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(142, 31);
            this.label1.TabIndex = 1;
            this.label1.Text = "Getz Tech";
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(33, 202);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(75, 73);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(33, 293);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(75, 73);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 3;
            this.pictureBox3.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(33, 385);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(75, 73);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 4;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(33, 478);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(75, 73);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 5;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(33, 569);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(75, 73);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 6;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox7.Image")));
            this.pictureBox7.Location = new System.Drawing.Point(32, 739);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(75, 73);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox7.TabIndex = 1;
            this.pictureBox7.TabStop = false;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Sitka Banner", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Crimson;
            this.label2.Location = new System.Drawing.Point(351, 28);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(328, 39);
            this.label2.TabIndex = 1;
            this.label2.Text = "Personal Finance Dashboard";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Sitka Banner", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Crimson;
            this.label3.Location = new System.Drawing.Point(114, 218);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(135, 39);
            this.label3.TabIndex = 7;
            this.label3.Text = "Dashboard";
            // 
            // IncLbl
            // 
            this.IncLbl.AutoSize = true;
            this.IncLbl.Font = new System.Drawing.Font("Sitka Banner", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IncLbl.ForeColor = System.Drawing.Color.Black;
            this.IncLbl.Location = new System.Drawing.Point(114, 310);
            this.IncLbl.Name = "IncLbl";
            this.IncLbl.Size = new System.Drawing.Size(98, 39);
            this.IncLbl.TabIndex = 8;
            this.IncLbl.Text = "Income";
            this.IncLbl.Click += new System.EventHandler(this.IncLbl_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Sitka Banner", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(114, 401);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(109, 39);
            this.label5.TabIndex = 9;
            this.label5.Text = "Expense";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Sitka Banner", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(114, 496);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(158, 39);
            this.label6.TabIndex = 10;
            this.label6.Text = "View Income";
            this.label6.Click += new System.EventHandler(this.label6_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Sitka Banner", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(114, 587);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(169, 39);
            this.label7.TabIndex = 11;
            this.label7.Text = "View Expense";
            this.label7.Click += new System.EventHandler(this.label7_Click);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Sitka Banner", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(113, 758);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(93, 39);
            this.label8.TabIndex = 9;
            this.label8.Text = "Logout";
            this.label8.Click += new System.EventHandler(this.label8_Click);
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackColor = System.Drawing.Color.Purple;
            this.pictureBox8.Location = new System.Drawing.Point(376, 123);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(439, 267);
            this.pictureBox8.TabIndex = 2;
            this.pictureBox8.TabStop = false;
            // 
            // pictureBox9
            // 
            this.pictureBox9.BackColor = System.Drawing.Color.Purple;
            this.pictureBox9.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox9.Image")));
            this.pictureBox9.Location = new System.Drawing.Point(683, 123);
            this.pictureBox9.Name = "pictureBox9";
            this.pictureBox9.Size = new System.Drawing.Size(132, 127);
            this.pictureBox9.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox9.TabIndex = 3;
            this.pictureBox9.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.BackColor = System.Drawing.Color.Purple;
            this.label9.Font = new System.Drawing.Font("Sitka Banner", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.Gold;
            this.label9.Location = new System.Drawing.Point(408, 138);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(159, 39);
            this.label9.TabIndex = 8;
            this.label9.Text = "Total Income";
            // 
            // TotIncLbl
            // 
            this.TotIncLbl.AutoSize = true;
            this.TotIncLbl.BackColor = System.Drawing.Color.Purple;
            this.TotIncLbl.Font = new System.Drawing.Font("Leelawadee UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotIncLbl.ForeColor = System.Drawing.Color.Gold;
            this.TotIncLbl.Location = new System.Drawing.Point(410, 188);
            this.TotIncLbl.Name = "TotIncLbl";
            this.TotIncLbl.Size = new System.Drawing.Size(162, 28);
            this.TotIncLbl.TabIndex = 9;
            this.TotIncLbl.Text = "AmountInRupees";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.Color.Purple;
            this.label11.Font = new System.Drawing.Font("Leelawadee UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.Gold;
            this.label11.Location = new System.Drawing.Point(388, 263);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(120, 28);
            this.label11.TabIndex = 10;
            this.label11.Text = "Transactions";
            // 
            // NumIncLbl
            // 
            this.NumIncLbl.AutoSize = true;
            this.NumIncLbl.BackColor = System.Drawing.Color.Purple;
            this.NumIncLbl.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NumIncLbl.ForeColor = System.Drawing.Color.Gold;
            this.NumIncLbl.Location = new System.Drawing.Point(405, 293);
            this.NumIncLbl.Name = "NumIncLbl";
            this.NumIncLbl.Size = new System.Drawing.Size(95, 24);
            this.NumIncLbl.TabIndex = 11;
            this.NumIncLbl.Text = "Number";
            // 
            // DateIncLbl
            // 
            this.DateIncLbl.AutoSize = true;
            this.DateIncLbl.BackColor = System.Drawing.Color.Purple;
            this.DateIncLbl.Font = new System.Drawing.Font("Sitka Banner", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DateIncLbl.ForeColor = System.Drawing.Color.GhostWhite;
            this.DateIncLbl.Location = new System.Drawing.Point(463, 337);
            this.DateIncLbl.Name = "DateIncLbl";
            this.DateIncLbl.Size = new System.Drawing.Size(244, 39);
            this.DateIncLbl.TabIndex = 12;
            this.DateIncLbl.Text = "LastTransactionDate";
            // 
            // DateExpLbl
            // 
            this.DateExpLbl.AutoSize = true;
            this.DateExpLbl.BackColor = System.Drawing.Color.DeepPink;
            this.DateExpLbl.Font = new System.Drawing.Font("Sitka Banner", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DateExpLbl.ForeColor = System.Drawing.Color.GhostWhite;
            this.DateExpLbl.Location = new System.Drawing.Point(463, 643);
            this.DateExpLbl.Name = "DateExpLbl";
            this.DateExpLbl.Size = new System.Drawing.Size(244, 39);
            this.DateExpLbl.TabIndex = 19;
            this.DateExpLbl.Text = "LastTransactionDate";
            // 
            // NumExpLbl
            // 
            this.NumExpLbl.AutoSize = true;
            this.NumExpLbl.BackColor = System.Drawing.Color.DeepPink;
            this.NumExpLbl.Font = new System.Drawing.Font("Georgia", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NumExpLbl.ForeColor = System.Drawing.Color.Gold;
            this.NumExpLbl.Location = new System.Drawing.Point(405, 599);
            this.NumExpLbl.Name = "NumExpLbl";
            this.NumExpLbl.Size = new System.Drawing.Size(95, 24);
            this.NumExpLbl.TabIndex = 18;
            this.NumExpLbl.Text = "Number";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.BackColor = System.Drawing.Color.DeepPink;
            this.label16.Font = new System.Drawing.Font("Leelawadee UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.Gold;
            this.label16.Location = new System.Drawing.Point(388, 569);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(120, 28);
            this.label16.TabIndex = 17;
            this.label16.Text = "Transactions";
            // 
            // TotExpLbl
            // 
            this.TotExpLbl.AutoSize = true;
            this.TotExpLbl.BackColor = System.Drawing.Color.DeepPink;
            this.TotExpLbl.Font = new System.Drawing.Font("Leelawadee UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotExpLbl.ForeColor = System.Drawing.Color.Gold;
            this.TotExpLbl.Location = new System.Drawing.Point(410, 494);
            this.TotExpLbl.Name = "TotExpLbl";
            this.TotExpLbl.Size = new System.Drawing.Size(162, 28);
            this.TotExpLbl.TabIndex = 16;
            this.TotExpLbl.Text = "AmountInRupees";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.BackColor = System.Drawing.Color.DeepPink;
            this.label18.Font = new System.Drawing.Font("Sitka Banner", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.Gold;
            this.label18.Location = new System.Drawing.Point(408, 444);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(170, 39);
            this.label18.TabIndex = 15;
            this.label18.Text = "Total Expense";
            // 
            // pictureBox10
            // 
            this.pictureBox10.BackColor = System.Drawing.Color.DeepPink;
            this.pictureBox10.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox10.Image")));
            this.pictureBox10.Location = new System.Drawing.Point(683, 429);
            this.pictureBox10.Name = "pictureBox10";
            this.pictureBox10.Size = new System.Drawing.Size(132, 127);
            this.pictureBox10.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox10.TabIndex = 14;
            this.pictureBox10.TabStop = false;
            // 
            // pictureBox11
            // 
            this.pictureBox11.BackColor = System.Drawing.Color.DeepPink;
            this.pictureBox11.Location = new System.Drawing.Point(376, 429);
            this.pictureBox11.Name = "pictureBox11";
            this.pictureBox11.Size = new System.Drawing.Size(439, 267);
            this.pictureBox11.TabIndex = 13;
            this.pictureBox11.TabStop = false;
            // 
            // pictureBox12
            // 
            this.pictureBox12.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox12.Image")));
            this.pictureBox12.Location = new System.Drawing.Point(1447, 12);
            this.pictureBox12.Name = "pictureBox12";
            this.pictureBox12.Size = new System.Drawing.Size(40, 43);
            this.pictureBox12.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox12.TabIndex = 20;
            this.pictureBox12.TabStop = false;
            this.pictureBox12.Click += new System.EventHandler(this.pictureBox12_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.BackColor = System.Drawing.Color.Aquamarine;
            this.label23.Font = new System.Drawing.Font("Sitka Banner", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.DarkMagenta;
            this.label23.Location = new System.Drawing.Point(899, 97);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(216, 39);
            this.label23.TabIndex = 23;
            this.label23.Text = "Maximum Income";
            // 
            // pictureBox14
            // 
            this.pictureBox14.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox14.Location = new System.Drawing.Point(873, 82);
            this.pictureBox14.Name = "pictureBox14";
            this.pictureBox14.Size = new System.Drawing.Size(283, 134);
            this.pictureBox14.TabIndex = 21;
            this.pictureBox14.TabStop = false;
            // 
            // MaxIncLbl
            // 
            this.MaxIncLbl.AutoSize = true;
            this.MaxIncLbl.BackColor = System.Drawing.Color.Aquamarine;
            this.MaxIncLbl.Font = new System.Drawing.Font("Leelawadee UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaxIncLbl.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.MaxIncLbl.Location = new System.Drawing.Point(921, 147);
            this.MaxIncLbl.Name = "MaxIncLbl";
            this.MaxIncLbl.Size = new System.Drawing.Size(162, 28);
            this.MaxIncLbl.TabIndex = 24;
            this.MaxIncLbl.Text = "AmountInRupees";
            // 
            // MaxExpLbl
            // 
            this.MaxExpLbl.AutoSize = true;
            this.MaxExpLbl.BackColor = System.Drawing.Color.Aquamarine;
            this.MaxExpLbl.Font = new System.Drawing.Font("Leelawadee UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaxExpLbl.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.MaxExpLbl.Location = new System.Drawing.Point(921, 330);
            this.MaxExpLbl.Name = "MaxExpLbl";
            this.MaxExpLbl.Size = new System.Drawing.Size(162, 28);
            this.MaxExpLbl.TabIndex = 27;
            this.MaxExpLbl.Text = "AmountInRupees";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Aquamarine;
            this.label21.Font = new System.Drawing.Font("Sitka Banner", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.DarkMagenta;
            this.label21.Location = new System.Drawing.Point(888, 280);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(227, 39);
            this.label21.TabIndex = 26;
            this.label21.Text = "Maximum Expense";
            // 
            // pictureBox13
            // 
            this.pictureBox13.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox13.Location = new System.Drawing.Point(873, 265);
            this.pictureBox13.Name = "pictureBox13";
            this.pictureBox13.Size = new System.Drawing.Size(283, 134);
            this.pictureBox13.TabIndex = 25;
            this.pictureBox13.TabStop = false;
            // 
            // MinIncLbl
            // 
            this.MinIncLbl.AutoSize = true;
            this.MinIncLbl.BackColor = System.Drawing.Color.Aquamarine;
            this.MinIncLbl.Font = new System.Drawing.Font("Leelawadee UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinIncLbl.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.MinIncLbl.Location = new System.Drawing.Point(921, 520);
            this.MinIncLbl.Name = "MinIncLbl";
            this.MinIncLbl.Size = new System.Drawing.Size(162, 28);
            this.MinIncLbl.TabIndex = 30;
            this.MinIncLbl.Text = "AmountInRupees";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.BackColor = System.Drawing.Color.Aquamarine;
            this.label24.Font = new System.Drawing.Font("Sitka Banner", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.DarkMagenta;
            this.label24.Location = new System.Drawing.Point(902, 470);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(213, 39);
            this.label24.TabIndex = 29;
            this.label24.Text = "Minimum Income";
            // 
            // pictureBox15
            // 
            this.pictureBox15.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox15.Location = new System.Drawing.Point(873, 455);
            this.pictureBox15.Name = "pictureBox15";
            this.pictureBox15.Size = new System.Drawing.Size(283, 134);
            this.pictureBox15.TabIndex = 28;
            this.pictureBox15.TabStop = false;
            // 
            // MinExpLbl
            // 
            this.MinExpLbl.AutoSize = true;
            this.MinExpLbl.BackColor = System.Drawing.Color.Aquamarine;
            this.MinExpLbl.Font = new System.Drawing.Font("Leelawadee UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinExpLbl.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.MinExpLbl.Location = new System.Drawing.Point(921, 707);
            this.MinExpLbl.Name = "MinExpLbl";
            this.MinExpLbl.Size = new System.Drawing.Size(162, 28);
            this.MinExpLbl.TabIndex = 33;
            this.MinExpLbl.Text = "AmountInRupees";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.BackColor = System.Drawing.Color.Aquamarine;
            this.label26.Font = new System.Drawing.Font("Sitka Banner", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.DarkMagenta;
            this.label26.Location = new System.Drawing.Point(899, 657);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(224, 39);
            this.label26.TabIndex = 32;
            this.label26.Text = "Minimum Expense";
            // 
            // pictureBox16
            // 
            this.pictureBox16.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox16.Location = new System.Drawing.Point(873, 642);
            this.pictureBox16.Name = "pictureBox16";
            this.pictureBox16.Size = new System.Drawing.Size(283, 134);
            this.pictureBox16.TabIndex = 31;
            this.pictureBox16.TabStop = false;
            // 
            // BestIncLbl
            // 
            this.BestIncLbl.AutoSize = true;
            this.BestIncLbl.BackColor = System.Drawing.Color.Aquamarine;
            this.BestIncLbl.Font = new System.Drawing.Font("Leelawadee UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BestIncLbl.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.BestIncLbl.Location = new System.Drawing.Point(1260, 707);
            this.BestIncLbl.Name = "BestIncLbl";
            this.BestIncLbl.Size = new System.Drawing.Size(162, 28);
            this.BestIncLbl.TabIndex = 45;
            this.BestIncLbl.Text = "AmountInRupees";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.BackColor = System.Drawing.Color.Aquamarine;
            this.label28.Font = new System.Drawing.Font("Sitka Banner", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.DarkMagenta;
            this.label28.Location = new System.Drawing.Point(1216, 657);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(253, 39);
            this.label28.TabIndex = 44;
            this.label28.Text = "Best Income Categary";
            // 
            // pictureBox17
            // 
            this.pictureBox17.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox17.Location = new System.Drawing.Point(1212, 642);
            this.pictureBox17.Name = "pictureBox17";
            this.pictureBox17.Size = new System.Drawing.Size(286, 134);
            this.pictureBox17.TabIndex = 43;
            this.pictureBox17.TabStop = false;
            // 
            // BalanceLbl
            // 
            this.BalanceLbl.AutoSize = true;
            this.BalanceLbl.BackColor = System.Drawing.Color.Aquamarine;
            this.BalanceLbl.Font = new System.Drawing.Font("Leelawadee UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BalanceLbl.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.BalanceLbl.Location = new System.Drawing.Point(1260, 520);
            this.BalanceLbl.Name = "BalanceLbl";
            this.BalanceLbl.Size = new System.Drawing.Size(162, 28);
            this.BalanceLbl.TabIndex = 42;
            this.BalanceLbl.Text = "AmountInRupees";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.BackColor = System.Drawing.Color.Aquamarine;
            this.label30.Font = new System.Drawing.Font("Sitka Banner", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.DarkMagenta;
            this.label30.Location = new System.Drawing.Point(1293, 470);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(101, 39);
            this.label30.TabIndex = 41;
            this.label30.Text = "Balance";
            // 
            // pictureBox18
            // 
            this.pictureBox18.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox18.Location = new System.Drawing.Point(1212, 455);
            this.pictureBox18.Name = "pictureBox18";
            this.pictureBox18.Size = new System.Drawing.Size(286, 134);
            this.pictureBox18.TabIndex = 40;
            this.pictureBox18.TabStop = false;
            // 
            // DateExpLbl1
            // 
            this.DateExpLbl1.AutoSize = true;
            this.DateExpLbl1.BackColor = System.Drawing.Color.Aquamarine;
            this.DateExpLbl1.Font = new System.Drawing.Font("Leelawadee UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DateExpLbl1.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.DateExpLbl1.Location = new System.Drawing.Point(1218, 362);
            this.DateExpLbl1.Name = "DateExpLbl1";
            this.DateExpLbl1.Size = new System.Drawing.Size(164, 28);
            this.DateExpLbl1.TabIndex = 39;
            this.DateExpLbl1.Text = "LastExpenseDatte";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.BackColor = System.Drawing.Color.Aquamarine;
            this.label32.Font = new System.Drawing.Font("Sitka Banner", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.DarkMagenta;
            this.label32.Location = new System.Drawing.Point(1263, 280);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(161, 39);
            this.label32.TabIndex = 38;
            this.label32.Text = "Last Expense";
            // 
            // pictureBox19
            // 
            this.pictureBox19.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox19.Location = new System.Drawing.Point(1212, 265);
            this.pictureBox19.Name = "pictureBox19";
            this.pictureBox19.Size = new System.Drawing.Size(286, 134);
            this.pictureBox19.TabIndex = 37;
            this.pictureBox19.TabStop = false;
            // 
            // DateIncLbl1
            // 
            this.DateIncLbl1.AutoSize = true;
            this.DateIncLbl1.BackColor = System.Drawing.Color.Aquamarine;
            this.DateIncLbl1.Font = new System.Drawing.Font("Leelawadee UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DateIncLbl1.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.DateIncLbl1.Location = new System.Drawing.Point(1232, 176);
            this.DateIncLbl1.Name = "DateIncLbl1";
            this.DateIncLbl1.Size = new System.Drawing.Size(151, 28);
            this.DateIncLbl1.TabIndex = 36;
            this.DateIncLbl1.Text = "LastIncomeDate";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.BackColor = System.Drawing.Color.Aquamarine;
            this.label34.Font = new System.Drawing.Font("Sitka Banner", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.DarkMagenta;
            this.label34.Location = new System.Drawing.Point(1263, 97);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(150, 39);
            this.label34.TabIndex = 35;
            this.label34.Text = "Last Income";
            // 
            // pictureBox20
            // 
            this.pictureBox20.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox20.Location = new System.Drawing.Point(1212, 82);
            this.pictureBox20.Name = "pictureBox20";
            this.pictureBox20.Size = new System.Drawing.Size(286, 134);
            this.pictureBox20.TabIndex = 34;
            this.pictureBox20.TabStop = false;
            // 
            // BestExpLbl
            // 
            this.BestExpLbl.AutoSize = true;
            this.BestExpLbl.BackColor = System.Drawing.Color.Aquamarine;
            this.BestExpLbl.Font = new System.Drawing.Font("Leelawadee UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BestExpLbl.ForeColor = System.Drawing.Color.DarkOliveGreen;
            this.BestExpLbl.Location = new System.Drawing.Point(424, 784);
            this.BestExpLbl.Name = "BestExpLbl";
            this.BestExpLbl.Size = new System.Drawing.Size(162, 28);
            this.BestExpLbl.TabIndex = 48;
            this.BestExpLbl.Text = "AmountInRupees";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.BackColor = System.Drawing.Color.Aquamarine;
            this.label36.Font = new System.Drawing.Font("Sitka Banner", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.DarkMagenta;
            this.label36.Location = new System.Drawing.Point(402, 733);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(265, 39);
            this.label36.TabIndex = 47;
            this.label36.Text = "Best Expense Category";
            // 
            // pictureBox21
            // 
            this.pictureBox21.BackColor = System.Drawing.Color.Aquamarine;
            this.pictureBox21.Location = new System.Drawing.Point(376, 719);
            this.pictureBox21.Name = "pictureBox21";
            this.pictureBox21.Size = new System.Drawing.Size(314, 134);
            this.pictureBox21.TabIndex = 46;
            this.pictureBox21.TabStop = false;
            // 
            // DashBoard
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Lavender;
            this.ClientSize = new System.Drawing.Size(1529, 913);
            this.Controls.Add(this.BestExpLbl);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.pictureBox21);
            this.Controls.Add(this.BestIncLbl);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.pictureBox17);
            this.Controls.Add(this.BalanceLbl);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.pictureBox18);
            this.Controls.Add(this.DateExpLbl1);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.pictureBox19);
            this.Controls.Add(this.DateIncLbl1);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.pictureBox20);
            this.Controls.Add(this.MinExpLbl);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.pictureBox16);
            this.Controls.Add(this.MinIncLbl);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.pictureBox15);
            this.Controls.Add(this.MaxExpLbl);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.pictureBox13);
            this.Controls.Add(this.MaxIncLbl);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.pictureBox14);
            this.Controls.Add(this.pictureBox12);
            this.Controls.Add(this.DateExpLbl);
            this.Controls.Add(this.NumExpLbl);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.TotExpLbl);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.pictureBox10);
            this.Controls.Add(this.pictureBox11);
            this.Controls.Add(this.DateIncLbl);
            this.Controls.Add(this.NumIncLbl);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.TotIncLbl);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.pictureBox9);
            this.Controls.Add(this.pictureBox8);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "DashBoard";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox9)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox10)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox12)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox14)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox13)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox15)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox16)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox17)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox18)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox19)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox20)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox21)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label IncLbl;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.PictureBox pictureBox9;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label TotIncLbl;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label NumIncLbl;
        private System.Windows.Forms.Label DateIncLbl;
        private System.Windows.Forms.Label DateExpLbl;
        private System.Windows.Forms.Label NumExpLbl;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label TotExpLbl;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox pictureBox10;
        private System.Windows.Forms.PictureBox pictureBox11;
        private System.Windows.Forms.PictureBox pictureBox12;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.PictureBox pictureBox14;
        private System.Windows.Forms.Label MaxIncLbl;
        private System.Windows.Forms.Label MaxExpLbl;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.PictureBox pictureBox13;
        private System.Windows.Forms.Label MinIncLbl;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.PictureBox pictureBox15;
        private System.Windows.Forms.Label MinExpLbl;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.PictureBox pictureBox16;
        private System.Windows.Forms.Label BestIncLbl;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.PictureBox pictureBox17;
        private System.Windows.Forms.Label BalanceLbl;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.PictureBox pictureBox18;
        private System.Windows.Forms.Label DateExpLbl1;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.PictureBox pictureBox19;
        private System.Windows.Forms.Label DateIncLbl1;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.PictureBox pictureBox20;
        private System.Windows.Forms.Label BestExpLbl;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.PictureBox pictureBox21;
    }
}

