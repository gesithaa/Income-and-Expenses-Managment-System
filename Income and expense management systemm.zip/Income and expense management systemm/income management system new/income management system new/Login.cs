﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace income_management_system_new
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            Users obj = new Users();
            obj.Show();
        }
        SqlConnection Con = new SqlConnection(@"Data Source=(LocalDB)\v11.0;AttachDbFilename=C:\Users\buzz1\OneDrive\Documents\income.mdf;Integrated Security=True;Connect Timeout=30");
        public static string User;
        private void LoginBtn_Click(object sender, EventArgs e)
        {
            if (UnameTb.Text == "" || PasswordTb.Text == "")
            {
                MessageBox.Show("Enter Both UserName And Password");
            }
            else
            { 
              
            }
            Con.Open();
            SqlDataAdapter sda = new SqlDataAdapter("select count(*) from userTbl where UName='"+UnameTb.Text+"' and UPass='"+PasswordTb.Text+"'",Con);

            DataTable dt = new DataTable();
            sda.Fill(dt);
            if (dt.Rows[0][0].ToString() == "1")
            {
                User = UnameTb.Text;
                DashBoard Obj = new DashBoard();
                Obj.Show();
                this.Hide();
                Con.Close();
            }
            else
            {
                MessageBox.Show("Wrong userName or Password!!!");
                UnameTb.Text = "";
                PasswordTb.Text = "";
            }
            Con.Close();
        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
