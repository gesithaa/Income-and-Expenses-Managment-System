﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Data.SqlClient;
namespace WindowsFormsApplication1
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        string dbcon = "datasource=127.0.0.1;port=3306;username=root;password=;database=getztech";

        private void button1_Click(object sender, EventArgs e)
        {

            //String username = UnameTb.Text;
            //String password = PasswordTb.Text;

            //if (username == "")
            //{
            //    MessageBox.Show("Enter the username ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
            //else if (password == "")
            //{
            //    MessageBox.Show("Enter the password ", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}
            //else
            //{

            //    MySqlConnection Con = new MySqlConnection();


            //    string query = "SELECT * FROM login where Username='" + UnameTb.Text + "' and Password='" + PasswordTb.Text + "'";
            //    MySqlCommand queryCmd = new MySqlCommand(query,Con);

            //    DashBoard dashboard = new DashBoard();
            //    dashboard.ShowDialog();

            //}

        }

        private void label5_Click(object sender, EventArgs e)
        {
            User Obj = new User();
            Obj.Show();

        }
       
        

        private void label5_Click_1(object sender, EventArgs e)
        {

        }


            
        private void LoginBtn_Click(object sender, EventArgs e)
        {
            if (UnameTb.Text == "" || PasswordTb.Text == "")
            {
                MessageBox.Show("Enter Both UserName & Password");
            }
            else
            {
                 MySqlConnection Con = new MySqlConnection();
      
                Con.Open();
                MySqlDataAdapter sda = new MySqlDataAdapter();
                string query = "select * from UserTbl where UName='" + UnameTb.Text + "' and UPass='" + PasswordTb.Text + "'";
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows[0][0].ToString() == "1")
                {
                    String User = UnameTb.Text;
                    DashBoard obj = new DashBoard();
                    obj.Show();
                    this.Hide();
                    Con.Close();
                }


                else
                {
                    MessageBox.Show("Wrong UserName of Password!!!");
                    UnameTb.Text = "";
                    PasswordTb.Text = "";

                }
                Con.Close();
            }
        }
    }
}
